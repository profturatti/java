package aula7;
import javax.swing.JOptionPane;
public class Teste {
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			PessoaFisica pf = new PessoaFisica();
			Aluno a1 = new Aluno();
			pf.setNome(JOptionPane.showInputDialog("Digite o nome da pessoa física"));
			pf.setEndereço(JOptionPane.showInputDialog("Digite o endereço da pessoa física"));
			pf.setIdade(Integer.parseInt(JOptionPane.showInputDialog("Digite a idade da pessoa física")));
			pf.setRg(JOptionPane.showInputDialog("Digite o RG da pessoa física"));
			pf.setCpf(JOptionPane.showInputDialog("Digite o CPF da pessoa física"));
			a1.setNome(JOptionPane.showInputDialog("Digite o nome do aluno"));
			a1.setEndereço(JOptionPane.showInputDialog("Digite o endereço do aluno"));
			a1.setIdade(Integer.parseInt(JOptionPane.showInputDialog("Digite a idade do aluno")));
			a1.setRg(JOptionPane.showInputDialog("Digite o RG do aluno"));
			a1.setCpf(JOptionPane.showInputDialog("Digite o CPF do aluno"));
			a1.setMatr(Integer.parseInt(JOptionPane.showInputDialog("Digite a matrícula do aluno")));
			a1.setCurso(JOptionPane.showInputDialog("Digite o curso do aluno"));
			JOptionPane.showMessageDialog(null,pf);
			JOptionPane.showMessageDialog(null,a1);
		}
	}
