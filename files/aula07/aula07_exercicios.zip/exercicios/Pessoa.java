package aula7;

public class Pessoa {
	protected String nome;
	protected String endereço;

	public Pessoa(String nome, String endereço) {
		this.nome = nome;
		this.endereço = endereço;
	}

	public Pessoa() {
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEndereço() {
		return endereço;
	}

	public void setEndereço(String endereço) {
		this.endereço = endereço;
	}

	public String toString() {
		return "Nome: " + nome + "\n" + "Endereço: " + endereço;
	}
}

public class PessoaFisica extends Pessoa {
	private int idade;
	private String rg;
	private String cpf;

	public PessoaFisica(String nome, String endereço, int idade, String rg, String cpf) {
		super(nome, endereço);
		this.idade = idade;
		this.rg = rg;
		this.cpf = cpf;
	}

	public PessoaFisica() {
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public String getRg() {
		return rg;
	}

	public void setRg(String rg) {
		this.rg = rg;
	}

	public String getCPF() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;		
	}

	public String toString() {
		return super.toString() + "\n" + "Idade: " + idade + "\n" + "R.G.: " + rg + "\n" + "C.P.F." + cpf;
	}	
}

public class PessoaJuridica extends Pessoa{
	private String cnpj;
	private String ie;
	
public PessoaJuridica (String nome, String endereço, String cnpj, String ie) {
  super(nome, endereço);
	  this.cnpj=cnpj;
	  this.ie=ie;
}
public PessoaJuridica() {
} 
public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	public String getIe() {
		return ie;
	}
	public void setIe(String ie) {
		this.ie = ie;
	}
	public String toString() {
		return super.toString()+"\n"+
		   "C.N.P.J.: "+cnpj+"\n"+
		   "I.E."+ie;
	}	
}

public class Aluno extends PessoaFisica {
	private int matr;
	private String curso;
	public Aluno(String nome, String endereço, int idade, String rg,
			String cpf, String curso, int matr) {
		super(nome, endereço, idade, rg, cpf);
		this.curso = curso;
		this.matr = matr;
	}
	public Aluno() {
		super();
	}
	public int getMatr() {
		return matr;
	}
	public void setMatr(int matr) {
		this.matr = matr;
	}
	public String getCurso() {
		return curso;
	}
	public void setCurso(String curso) {
		this.curso = curso;
	}
	public String toString() {
		return super.toString()+"\n"+
	   		   "Matrícula: "+matr+"\n"+
			   "Curso: "+curso;
	}
}
