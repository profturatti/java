package aula5;
//Classe Carro: Define o projeto/modelo para todos os carros.

class Carro {
    // Atributos (características do carro)
    String modelo; 
    String cor;
    String motor;
    int velocidadeAtual;
    // Construtor: Um método especial chamado ao criar um novo objeto.
    // Ele inicializa os atributos do carro.
    Carro(String modeloVal, String corVal, String motorVal) {
        modelo = modeloVal;
        cor = corVal;
        motor = motorVal;
        velocidadeAtual = 0; // Carro começa parado
    }

    // Métodos (ações que o carro pode realizar) 
    void acelerar (int incremento) {
        velocidadeAtual += incremento;
        System.out.println(modelo + " acelerou para " + velocidadeAtual + " km/h.");
    }

    void frear() {
        velocidadeAtual = 0;
        System.out.println(modelo + " freou e parou.");
    }

    void buzinar() {
        System.out.println("Bip! Bip! de " + modelo);
    }
}

