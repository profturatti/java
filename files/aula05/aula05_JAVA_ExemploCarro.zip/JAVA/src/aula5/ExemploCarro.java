package aula5;

public class ExemploCarro {
    public static void main(String[] args) {
        // Criando o primeiro objeto Carro (carro1)
        Carro carro1 = new Carro("Sedan", "Preto", "1.6");

        // Interagindo com o carro1
        carro1.buzinar();
        carro1.acelerar(50);
        carro1.acelerar(30);
        carro1.frear();

        System.out.println("--------------------");

        // Criando o segundo objeto Carro (carro2)
        Carro carro2 = new Carro("SUV", "Branco", "2.0");

        // Interagindo com o carro2 (independentemente do carro1)
        carro2.buzinar();
        carro2.acelerar(40);
        carro2.acelerar(20);
        carro2.frear();
    }
}
